library(testthat)
library(eegstats)

test_check("eegstats")
